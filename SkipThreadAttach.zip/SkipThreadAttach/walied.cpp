#include "stdafx.h"
#include "windows.h"
#include "stdio.h"
 
BOOL APIENTRY DllMain(HANDLE hModule,int reason,void*)
{
        if(reason==DLL_THREAD_ATTACH)
        {
                MessageBox(0,"Thread attached","waliedassar",0);
        }
        else if(reason==DLL_THREAD_DETACH)
        {
                MessageBox(0,"Thread detached","waliedassar",0);
        }
        return TRUE;
}