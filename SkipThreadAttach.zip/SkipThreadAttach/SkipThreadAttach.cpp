#include "stdafx.h"
#include "windows.h"
#include "stdio.h"

//--------------------Definitions--------------------------
#define CreateSuspended  0x1
#define SuppressDllMains 0x2
#define HideFromDebugger 0x4
//--TEB bit flags--
#define DisableATlThunkEmulation 0x1
#define InDebugPrint             0x2
#define HasFiberData             0x4
#define SkipThreadAttach         0x8
#define WerShipAssert            0x10
#define RanProcessInit           0x20
#define ClonedThread             0x40
#define SuppressDebugMsg         0x80
#define CORSpecific              0x400 //.net application
//--------------------Structures-------------------------
struct UNICODE_S
{
        unsigned short len;
        unsigned short max;
        wchar_t* pStr;
};
struct OBJECT_ATTRIBUTES
{
  unsigned long           Length;
  HANDLE                  RootDirectory;
  UNICODE_S*              ObjectName;
  unsigned long           Attributes;
  void*           SecurityDescriptor;
  void*           SecurityQualityOfService;
};
//----------------------------------------------------------
typedef int(__stdcall *FUNC)(HANDLE* hThread,int DesiredAccess,OBJECT_ATTRIBUTES* ObjectAttributes,
HANDLE ProcessHandle,void* lpStartAddress,void* lpParameter,
unsigned long Flags,unsigned long StackZeroBits,
unsigned long SizeOfStackCommit,unsigned long SizeOfStackReserve,
void* lpBytesBuffer);


void Watch(unsigned char* pTEB)
{
	printf("New Thread\r\n");
	return;
}

int main(int argc, char* argv[])
{

	//---------Load a dummy dll-------------
	LoadLibrary("walied.dll");

	unsigned long tid=0;
	HANDLE hT=0;

	FUNC ZwCreateThreadEx=(FUNC)GetProcAddress(GetModuleHandle("ntdll.dll"),"ZwCreateThreadEx");
    if(ZwCreateThreadEx)
    {
		     HANDLE hThread=0;
             ZwCreateThreadEx(&hThread,0x1FFFFF,0,GetCurrentProcess(),&Watch,0,
                                    /*you can replace this flag with 0*/SuppressDllMains,
									0,0x1000,0x10000,0);
			ResumeThread(hThread);
	        WaitForSingleObject(hThread,INFINITE);
	}
	return 0;
}
